package nl.saxion.cds.application.main;

import nl.saxion.cds.application.console.Console;

public class Main {
    public static void main(String[] args) {
        Console console = new Console();

        console.start();

    }
}
