# CDS Opdracht (Nederlands)

zie [opdracht](<doc/Assignment (NL).md>).

# CDS Assignment (English)

see [assignment](<doc/Assignment (EN).md>).
